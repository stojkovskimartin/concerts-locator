$(document).ready(function (){
    $('#main').fadeIn(1000);
    $('#previousconcerts').delay(200).fadeIn(750);
    $('#sponsors').delay(200).fadeIn(750);
    $('#footer').delay(200).fadeIn(750);
});