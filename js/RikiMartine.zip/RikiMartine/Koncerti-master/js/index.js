$(document).ready(function (){
    $("#body").fadeIn(500);
    $("#nav").fadeIn(2000);
    $("#main").fadeIn(2000);
    $("#concertVenues").fadeIn(2000);
    $("#previousconcerts").fadeIn(3000);
    $("#sponsors").fadeIn(3000);
    $("#footer").fadeIn(3000);

});