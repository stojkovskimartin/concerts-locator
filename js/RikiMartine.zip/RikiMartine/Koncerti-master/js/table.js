$(document).ready(function (){

    /*$.getJSON("js/Koncerti.json", function (data) {
        var events = [];
        $.each(data, function (key, val) {
            var name = val.name;
            var link = '<a href=" ' + val.url + '">' + name + '</a>';
            var str = val.about;
            var tmp = str.toString();
            tmp = tmp.substr(0, 200);
            tmp = tmp.concat('...');
            var par = '<p>' + tmp + '</p>';

            events.push("<tr>");
            events.push("<td>" + link + "</td>");
            events.push("<td>" + val.place + "</td>");
            events.push("<td>" + val.date + "</td>");
            events.push("<td>" + par + "</td>");
            events.push("</tr>");

        });
        $("<tbody/>", {html: events.join("")}).appendTo("table");
    });*/

    $('#search').keydown(function () {
        $('#tmp').css("background-color","deepskyblue");
        $.getJSON("js/Koncerti.json",function (data) {
            var search = $('#search').val();
            var regex = new RegExp(search,'i');
            var output = '';
            var flag = 0;
            $.each(data,function (key,val) {
                if(val.name.search(regex) !== -1){
                    if(flag===0){
                        output += "<tr>";
                        output += "<th>Артист</th>";
                        output += "<th>Место</th>";
                        output += "<th>Датум</th>";
                        output += "<th>Опис</th>";
                        output += "</tr>";
                        flag = 1;
                    }
                    var name = val.name;
                    var link = '<a href=" ' + val.url + '">' + name + '</a>';
                    var str = val.about;
                    var tmp = str.toString();
                    tmp = tmp.substr(0, 200);
                    tmp = tmp.concat('...');
                    var par = '<p>' + tmp + '</p>';

                    output += "<tr>";
                    output += "<td>" + link + "</td>";
                    output += "<td>" + val.place + "</td>";
                    output += "<td>" + val.date + "</td>";
                    output += "<td>" + par + "</td>";
                    output += "</tr>";
                }
            });
            $('tbody').html(output);
        })
    })

});